/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 824:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.env = void 0;
exports.env = {
    message: process.env.MESSAGE,
};


/***/ }),

/***/ 882:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestResolver = void 0;
const environment_1 = __webpack_require__(824);
exports.TestResolver = {
    Query: {
        message: () => environment_1.env.message,
    },
};


/***/ }),

/***/ 690:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestType = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
exports.TestType = apollo_server_lambda_1.gql `
    type Query {
        message: String!
    }
`;


/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphql_handler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const test_1 = __webpack_require__(882);
const test_2 = __webpack_require__(690);
const apollo_server = new apollo_server_lambda_1.ApolloServer({ resolvers: test_1.TestResolver, typeDefs: test_2.TestType });
exports.graphql_handler = apollo_server.createHandler();

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL3NlcnZlci5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL2Nvb2stYm9vay12Mi8uL3NyYy9lbnZpcm9ubWVudC50cyIsIndlYnBhY2s6Ly9jb29rLWJvb2stdjIvLi9zcmMvcmVzb2x2ZXJzL3Rlc3QudHMiLCJ3ZWJwYWNrOi8vY29vay1ib29rLXYyLy4vc3JjL3NjaGVtYS90ZXN0LnRzIiwid2VicGFjazovL2Nvb2stYm9vay12Mi9leHRlcm5hbCBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIiLCJ3ZWJwYWNrOi8vY29vay1ib29rLXYyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2Nvb2stYm9vay12Mi8uL3NyYy9zZXJ2ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGVudiA9IHtcbiAgICBtZXNzYWdlOiBwcm9jZXNzLmVudi5NRVNTQUdFIGFzIHN0cmluZyxcbn0iLCJpbXBvcnQgeyBlbnYgfSBmcm9tICcuLi9lbnZpcm9ubWVudCc7XG5cbmV4cG9ydCBjb25zdCBUZXN0UmVzb2x2ZXIgPSB7XG4gICAgUXVlcnk6IHtcbiAgICAgICAgbWVzc2FnZTogKCkgPT4gZW52Lm1lc3NhZ2UsXG4gICAgfSxcbn07XG4iLCJpbXBvcnQgeyBncWwgfSBmcm9tICdhcG9sbG8tc2VydmVyLWxhbWJkYSc7XG5cbmV4cG9ydCBjb25zdCBUZXN0VHlwZSA9IGdxbGBcbiAgICB0eXBlIFF1ZXJ5IHtcbiAgICAgICAgbWVzc2FnZTogU3RyaW5nIVxuICAgIH1cbmA7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIik7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsImltcG9ydCB7IEFwb2xsb1NlcnZlciB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItbGFtYmRhJztcbmltcG9ydCB7IFRlc3RSZXNvbHZlciB9IGZyb20gJy4vcmVzb2x2ZXJzL3Rlc3QnO1xuaW1wb3J0IHsgVGVzdFR5cGUgfSBmcm9tICcuL3NjaGVtYS90ZXN0JztcblxuY29uc3QgYXBvbGxvX3NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoeyByZXNvbHZlcnM6IFRlc3RSZXNvbHZlciwgdHlwZURlZnM6IFRlc3RUeXBlIH0pXG5cbmV4cG9ydCBjb25zdCBncmFwaHFsX2hhbmRsZXIgPSBhcG9sbG9fc2VydmVyLmNyZWF0ZUhhbmRsZXIoKTsiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7OztBOzs7Ozs7OztBQ0ZBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0E7Ozs7Ozs7O0FDTkE7QUFFQTs7OztBQUlBOzs7QTs7Ozs7QUNOQTs7QTs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdkJBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7Ozs7Ozs7O0EiLCJzb3VyY2VSb290IjoiIn0=